	<footer class="main-footer">
	    <div class="pull-right hidden-xs"></div>
	    <strong>Copyright © 2019 - 2020 <a href="#">Itechnocode</a>.</strong> All rights reserved.
	</footer>
</div>
<!-- ./wrapper -->
@include('layouts.script')
</body>
</html>