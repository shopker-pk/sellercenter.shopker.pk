	<footer class="main-footer">
	    <div class="pull-right hidden-xs"></div>
	    <strong>Copyright © 2019 - 2020 <a href="#">Itechnocode</a>.</strong> All rights reserved.
	</footer>
</div>
<!-- ./wrapper -->
<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>